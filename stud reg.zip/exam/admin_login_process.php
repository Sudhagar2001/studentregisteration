<?php
session_start();
include('db_connection.php');

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM admin_users WHERE username=?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    // Verify password
    if (password_verify($password, $row['password'])) {
        // Password is correct, set session and redirect to admin dashboard
        $_SESSION['admin_username'] = $username;
        header("Location: admin_dashboard.php");
        exit(); // Stop further execution of the script after redirection
    } else {
        echo "Incorrect username or password.";
    }
} else {
    echo "Incorrect username or password.";
}

mysqli_close($conn);
?>
