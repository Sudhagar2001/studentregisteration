<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
       body {
        font-family: Arial, sans-serif;
   
   background-color: #f5f5f5;
   background-image: url('2.jpg'); /* Change 'your-background-image.jpg' to the path of your image */
   background-size: cover; /* Cover the entire background */
   background-position: center; /* Center the background image */

}

.navbar {
    background-color: #333;
    color: #fff;
    padding: 40px;
}

.navbar ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

.navbar ul li {
    display: inline;
    margin-right: 20px;
}

.navbar ul li a {
    color: #fff;
    text-decoration: none;
}

.navbar ul li a:hover {
    text-decoration: underline;
}

.container {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.container h2 {
    color: #333;
    margin-bottom: 10px;
}

.container p {
    color: #555;
    line-height: 1.6;
}

/* Responsive adjustments */
@media only screen and (max-width: 600px) {
    .container {
        padding: 10px;
    }
    .navbar ul li {
        display: block;
        margin: 10px 0;
    }
    .navbar ul li:last-child {
        float: none;
    }
}

    </style>
</head>
<body>
    <div class="navbar">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="submit_form.php">Application Form</a></li>
            <li style="float: right;"><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="container">
        <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
        <p>This is your dashboard.</p>
    </div>
</body>
</html>
