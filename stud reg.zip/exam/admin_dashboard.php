<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
       body {
        font-family: Arial, sans-serif;
   
   background-color: #f5f5f5;
   background-image: url('4.jpg'); /* Change 'your-background-image.jpg' to the path of your image */
   background-size: cover; /* Cover the entire background */
   background-position: center; /* Center the background image */

}

.sidebar {
    height: 100%;
    width: 250px;
    position: fixed;
    top: 0;
    left: 0;
    background-color: #333;
    padding-top: 20px;
    overflow-x: hidden;
}

.sidebar a {
    padding: 10px 15px;
    text-decoration: none;
    font-size: 18px;
    color: white;
    display: block;
}

.sidebar a:hover {
    background-color: #555;
}

.content {
    margin-left: 250px;
    padding: 20px;
}

.section {
    margin-bottom: 20px;
}

.section h2 {
    cursor: pointer;
    color: #333;
    background-color: #f2f2f2;
    padding: 10px;
    margin: 0;
}

.section-content {
    display: none;
    margin-top: 10px;
    border: 1px solid #ddd;
    padding: 10px;
    background-color: #fff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
}

.data-table th, .data-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.data-table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

    </style>
</head>
<body>
    <div class="sidebar">
        <!-- Sidebar content -->
        <a href="adminlogout.php">Logout</a>
        <!-- Add more sidebar links here if needed -->
    </div>

    <div class="content">
        <h1>Admin Dashboard</h1>

        <div id="submitted" class="section">
            <h2 onclick="toggleSection('submitted')">Submitted Form Data</h2>
            <div class="section-content">
                <?php
                // Include the database connection file
                include('db_connection.php');

                // Retrieve and display submitted form data
                $query = "SELECT * FROM student_registration";
                $result = mysqli_query($conn, $query);

                if ($result && mysqli_num_rows($result) > 0) {
                    echo '<table class="data-table">';
                    echo '<tr><th>ID</th><th>Name</th><th>Email</th><th>Date of Birth</th><th>Gender</th><th>Address</th><th>Phone Number</th><th>Course</th><th>Semester</th></tr>';
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>{$row['id']}</td>";
                        echo "<td>{$row['name']}</td>";
                        echo "<td>{$row['email']}</td>";
                        echo "<td>{$row['dob']}</td>";
                        echo "<td>{$row['gender']}</td>";
                        echo "<td>{$row['address']}</td>";
                        echo "<td>{$row['phone']}</td>";
                        echo "<td>{$row['course']}</td>";
                        echo "<td>{$row['semester']}</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "No submitted form data found.";
                }
                ?>
            </div>
        </div>

        <div id="registered" class="section">
            <h2 onclick="toggleSection('registered')">Registered Users</h2>
            <div class="section-content">
                <?php
                // Retrieve and display list of registered users
                $query_users = "SELECT * FROM users";
                $result_users = mysqli_query($conn, $query_users);

                if ($result_users && mysqli_num_rows($result_users) > 0) {
                    echo '<table class="data-table">';
                    echo '<tr><th>ID</th><th>Username</th><th>Email</th></tr>';
                    while ($row_users = mysqli_fetch_assoc($result_users)) {
                        echo "<tr>";
                        echo "<td>{$row_users['id']}</td>";
                        echo "<td>{$row_users['username']}</td>";
                        echo "<td>{$row_users['email']}</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "No registered users found.";
                }
                ?>
            </div>
        </div>
    </div>

    <script>
        function toggleSection(id) {
            var section = document.getElementById(id);
            var sectionContent = section.getElementsByClassName("section-content")[0];
            if (sectionContent.style.display === "none") {
                sectionContent.style.display = "block";
            } else {
                sectionContent.style.display = "none";
            }
        }
    </script>
</body>
</html>
