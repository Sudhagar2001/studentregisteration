<?php
session_start();
include('db_connection.php');

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username='$username'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
if ($row && password_verify($password, $row['password'])) {
    $_SESSION['username'] = $username;
    header("Location: dashboard.php");
} else {
    echo "Incorrect username or password.";
}
mysqli_close($conn);
?>
