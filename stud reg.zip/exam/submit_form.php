<?php
// Include the Dompdf autoload file
require 'vendor/autoload.php';

// Include the database connection file
include('db_connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);

    // Insert data into the database
    $query = "INSERT INTO student_registration (name, email, dob, gender, address, phone, course, semester) VALUES ('$name', '$email', '$dob', '$gender', '$address', '$phone', '$course', '$semester')";

    if (mysqli_query($conn, $query)) {
        // Generate PDF with form data using Dompdf
        $html = '
        <h1>Student Register Form</h1>
        <table border="1" cellpadding="5" cellspacing="0">
       
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Phone Number</th>
                <th>Course</th>
                <th>Semester</th>
            </tr>
            <tr>
                <td>' . $name . '</td>
                <td>' . $email . '</td>
                <td>' . $dob . '</td>
                <td>' . $gender . '</td>
                <td>' . $address . '</td>
                <td>' . $phone . '</td>
                <td>' . $course . '</td>
                <td>' . $semester . '</td>
            </tr>
        </table>';

        $dompdf = new Dompdf\Dompdf();
        $dompdf->loadHtml($html);

        // Set paper size
        $dompdf->setPaper('A4', 'portrait');

        // Render PDF
        $dompdf->render();

        // Output the PDF content
        $pdfContent = $dompdf->output();

        // Set response headers for PDF download
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="student_registration_form.pdf"');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Output the PDF content
        echo $pdfContent;
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // If the form is not submitted, redirect back to the form page
    header("Location: form.html");
    exit;
}
?>
